Guidelines:



1) cd's to project directory

2) copy all the input instance files in the ./input directory

3) execute the bash or batch script
, depending on the OS 
4) the output files can be found in the ./output directory


